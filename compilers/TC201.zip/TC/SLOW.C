#include <dos.h>

#define WIDTH 320
#define HEIGHT 200
#define TEXSIZE 32
#define PI 3.1415926

#include <math.h>

float distance(float x, float y)
{
  return sqrt(x*x + y*y);
}

void main()
{
    char texture[1024];

    typedef unsigned char byte;
    byte far *VGA = (byte far*)0xA0000000L;
    unsigned short texoffset = 0;
    unsigned short vgaoffset;
    int x;
    int y;
    int u;
    int v;

    int counter1 = 0;

    float a;
    float b;
    float r;

    byte color;

    union REGS regs;
    regs.h.ah = 0x00;
    regs.h.al = 0x13;
    int86(0x10,&regs,&regs);


    for(x=0;x<TEXSIZE;x++) {
       for(y=0;y<TEXSIZE;y++) {
	   color = x^y;
	   texoffset = TEXSIZE*y + x;
	   texture[texoffset] = color;
       }
   }

while(counter1 < 6)
{

   texoffset = 0;
   for(x=0;x<WIDTH-1;x++) {
     for(y=0;y<HEIGHT-1;y++) {
	vgaoffset = WIDTH*y+x;

	u = x-WIDTH/2;
	v = y-HEIGHT/2;

	r = distance(u,v);
	if((int)r < 10.0) continue;
	/*r = 0.3/r;*/

	a = 128 * (atan2((y - HEIGHT / 2), (x - WIDTH / 2)) / PI + 1);

	/*a = atan2(x,y);*/
	a = a + 182.5;

	u = r+counter1;
	v = a;

	u = u%TEXSIZE;
	v = v%TEXSIZE;

	texoffset = v * TEXSIZE + u;
	VGA[vgaoffset] = texture[texoffset];

     }
   }

   counter1++;

}



}

