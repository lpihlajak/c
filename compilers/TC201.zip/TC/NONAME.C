#include <dos.h>
#define WIDTH 320
#define HEIGHT 200
#define TEXSIZE 32

void main()
{
    char texture[1024];

    typedef unsigned char byte;
    byte far *VGA = (byte far*)0xA0000000L;
    unsigned short texoffset = 0;
    unsigned short vgaoffset;
    int x;
    int y;

    byte color;

    union REGS regs;
    regs.h.ah = 0x00;
    regs.h.al = 0x13;
    int86(0x10,&regs,&regs);


    for(x=0;x<TEXSIZE;x++) {
       for(y=0;y<TEXSIZE;y++) {
	   color = x^y;
	   texoffset = TEXSIZE*y + x;
	   texture[texoffset] = color;
       }
   }

   /*
   y = 0;
   for(x=0;x<1023;x++) {
     texture[x] = x%TEXSIZE^y;
     if(x%TEXSIZE == 0) y++;
   } */


   for(x=0;x<WIDTH-1;x++) {
     for(y=0;y<HEIGHT-1;y++) {
	vgaoffset = WIDTH*y+x;
	texoffset = (TEXSIZE*y) + x%TEXSIZE;
	VGA[vgaoffset] = texture[texoffset];

     }
   }
}

/*
float a = atan(y,x)
float r = length (xy)
flaoat inv_r = 0.3/r
texturecoord = vec2(inv_r+0.2*iTime , a/3.1415927(;
*/